<?php
function generateHexCode() {
  $hex = '';
  for($i=0; $i<16; $i++) {
    $hex .= dechex(rand(0,15));
  }
  return strtoupper($hex);
}

$code = generateHexCode();
echo $code."<br>";

@$encryptedPublicKey = openssl_encrypt($code, 'aes-256-cbc',""); 
echo $encryptedPublicKey."<br>";

@$decryptedpublicKey = openssl_decrypt($encryptedPublicKey,'aes-256-cbc',"");
echo $decryptedpublicKey
?>