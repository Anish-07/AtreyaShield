<?php

function decryptFile($inputFile, $outputFile, $key) {
    // Open the input and output files
    $inFile = fopen($inputFile, "rb");
    $outFile = fopen($outputFile, "wb");

    // Read the initialization vector from the input file
    $iv = fread($inFile, 16);
    // echo $iv;

    // Decrypt the file data with AES-256
    $cipherText = stream_get_contents($inFile);
    $plainText = openssl_decrypt($cipherText, "aes-256-cbc", $key, OPENSSL_RAW_DATA, $iv);

    // Write the decrypted data to the output file
    fwrite($outFile, $plainText);

    // Close the input and output files
    fclose($inFile);
    fclose($outFile);
}

//decryptFile('serverupload/230404073219pmencrypt_homeWhite.png','serverdownload/decrypt.png','*&@zxor)#^!+=]'. 1 . ')#^!+=]*&@zxor');
