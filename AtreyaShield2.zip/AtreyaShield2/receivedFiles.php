<?php include('session_manager.php');
$user_id = $_SESSION['id'];

$dbHost     = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName     = "atreyashield";

// Create database connection
$db = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

// Check connection
$sql2 = "SELECT * from received WHERE `RecID`='$user_id'";
$result = mysqli_query($db, $sql2);

if (mysqli_query($db, $sql2)) {
    //echo $result;
} else {
    echo "Sorry Please reload and try again!";
}

//FETCHING THE USER NAME
$sql3 = $db->prepare("SELECT * FROM users WHERE id='$user_id'");
$sql3->execute();
$result3 = $sql3->get_result();
$r3 = $result3->fetch_array(MYSQLI_ASSOC);
$userName = $r3['username'];


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="Bootstrap\bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Julee">
    <link id="onyx-css" href="sidebar_css.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>Dashboard-AtreyaShield</title>
    <style>
        .full-dark-bg {
            background-color: #D4D4D4;
        }

        .font_family {
            font-weight: 900;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        }

        /*GET KEY WALA PART FROM HERE  */
        #getKey-form-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            display: none;
            justify-content: center;
            align-items: center;
        }

        #getKey-form {
            background-color: #1f0838;
            height: 230px;
            width: 350px;
            padding: 20px;
            border-radius: 5px;
            border-color: #FFFFFF;
            border-style: dashed;
        }

        .getKey-form-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        /*DOWNLOAD WALA PART FROM HERE  */
        #download-form-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            display: none;
            justify-content: center;
            align-items: center;
        }

        #download-form {
            background-color: #1f0838;
            height: 200px;
            width: 350px;
            padding: 20px;
            border-radius: 5px;
            border-color: #FFFFFF;
            border-style: dashed;
        }

        .download-form-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="row">
        <div class="d-flex flex-column flex-shrink-0 p-3 text-white col-lg-2" style="background-color: #1f0838">
            <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                <img src="Logo\AtreyaShield-1.png" height="60px" width="60px">
                <span class="fs-4 font_family">AtreyaShield</span>
            </a>
            <hr>
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="myFiles.php" class="nav-link text-white font_family" aria-current="page" style="font-size: 15px; padding-left: 0px; padding-bottom: 10px;">
                        <svg class="bi me-2" width="16" height="16">
                        </svg>
                        <img src="PageIcons\homeWhite.png">&emsp;My Files
                    </a>
                </li>
                <li>
                    <a href="uploadFiles.php" class="nav-link text-white font_family" style="font-size: 15px; padding-left: 0px; margin-top: 15px;">
                        <svg class="bi me-2" width="16" height="16">
                        </svg>
                        <img src="PageIcons\uploadFilesWhite.png">&emsp;Upload Files
                    </a>
                </li>
                <li>
                    <a href="#" class="nav-link font_family" style="font-size: 18px; background-color: #FAFAFA; color: black; width: 110%; padding-left: 0px; margin-top: 15px;">
                        <svg class="bi me-2" width="16" height="16">
                        </svg>
                        &nbsp;<img src="PageIcons\receiveBlack.png">&emsp;Received Files
                    </a>
                </li>
            </ul>
            <hr>
            <div>
                <ul class="nav nav-pills flex-column mb-auto">
                    <li>
                        <a href="#" class="nav-link text-white font_family" style="font-size: 15px; width: 110%; padding-left: 0px; margin-top: 0px;">
                            <svg class="bi me-2" width="16" height="16"></svg>
                            <img src="PageIcons\userWhite.png">&emsp;<?php echo $userName; ?>
                        </a>
                    </li>
                    <li>
                        <a href="logOut.php" class="nav-link text-white font_family" style="font-size: 15px; padding-left: 0px; margin-top: 15px;">
                            <svg class="bi me-2" width="16" height="16">
                            </svg>
                            <img src="PageIcons\logoutWhite.png">&emsp;Log Out
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-lg-10" style="background-color: #FAFAFA">
            <!-- Wrapper -->
            <div class="wrapper">
                <section class="container-fluid inner-page">
                    <div class="row">
                        <table class="table" style="margin-top: 40px; border-color: black;">
                            <thead class="thead-dark text-dark" style="font-size: 16px;">
                                <tr style="background-color: #1f0838; color:#D4D4D4;">
                                    <!-- <th scope="col">Sr No.</th> -->
                                    <th scope="col">File Name</th>
                                    <th scope="col">Shared By</th>
                                    <th scope="col">Time</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Get Key</th>
                                    <th scope="col">Download</th>
                                </tr>
                            </thead>
                            <tbody class="text-dark">
                                <?php
                                while ($row = mysqli_fetch_assoc($result)) { ?>
                                    <tr>
                                        <td><?php echo $row['FileName']; ?></td>
                                        <td><?php echo $row['SharedBy']; ?></td>
                                        <td><?php echo $row['SharedTime']; ?></td>
                                        <td><?php echo $row['SharedDate']; ?></td>
                                        <td><button class="openButton" style="background-color: #1f0838; color: #FFFFFF; border-radius: 11px; width: 110px; height: 35px; margin-left:-10px" onclick="openGetKeyForm(<?php echo $row['fileID']; ?>)">Get Key</button></td>
                                        <td><button class="openButton" style="background-color: #1f0838; color: #FFFFFF; border-radius: 11px; width: 110px; height: 35px; margin-left:-10px" onclick="openForm(<?php echo $row['fileID']; ?>)">Download</button></td>
                                    <tr>
                                    <?php } ?>
                            </tbody>
                        </table>


                        <!-- GET KEY BUTTON PART -->
                        <div id="getKey-form-container">
                            <form id="getKey-form">
                                <label style="color: #FFFFFF">Fetch Private Key</label>
                                <hr style="color: #FFFFFF; width: 100%; margin-top: -1px;">

                                <input type="text" id="encKey" class="form-control" placeholder="Paste Encrypted Key" required><br>
                                <input type="password" id="pvtPin" class="form-control" placeholder="Enter Private Pin" required>
                                <div class="getKey-form-buttons">
                                    <button type="button" onclick="closeForm()" style="background-color: #FFFFFF; color: #1f0838; border-radius: 11px; width: 90px; height: 37px; ">Cancel</button>
                                    <button type="submit" style="background-color: #FFFFFF; color: #1f0838; border-radius: 11px; width: 90px; height: 37px;" onclick="getKey()">Get Key</button>
                                </div>
                            </form>
                        </div>

                        <!-- DOWNLOAD BUTTON PART -->
                        <div id="download-form-container">
                            <form id="download-form">
                                <label style="color: #FFFFFF">Key Require to Download File</label>
                                <hr style="color: #FFFFFF; width: 100%; margin-top: -1px;">

                                <input type="password" id="key" class="form-control" placeholder="Enter Key" required>
                                <div class="download-form-buttons">
                                    <button type="button" onclick="closeForm()" style="background-color: #FFFFFF; color: #1f0838; border-radius: 11px; width: 90px; height: 37px; ">Cancel</button>
                                    <button type="submit" style="background-color: #FFFFFF; color: #1f0838; border-radius: 11px; width: 90px; height: 37px;" onclick="sendKey()">Download</button>

                                </div>
                            </form>
                        </div>

                        <div id="download0" style="display: none">
                        </div>
                        <script>
                            var uid;

                            function openForm(id) {
                                document.getElementById("download-form-container").style.display = "flex";
                                uid = id;

                            }

                            function openGetKeyForm(id) {
                                document.getElementById("getKey-form-container").style.display = "flex";
                                uid = id;

                            }

                            function closeForm() {
                                document.getElementById("getKey-form-container").style.display = "none";
                                document.getElementById("download-form-container").style.display = "none";
                                document.getElementById("share-form-container").style.display = "none";
                            }

                            function sendKey() {
                                m1 = uid;
                                m2 = document.getElementById("key").value;

                                $.ajax({
                                    type: "GET",
                                    url: "receivedVerification.php",
                                    data: {
                                        userID: m1,
                                        key: m2
                                    },
                                    success: function(data) {
                                        document.getElementById("download0").innerHTML = data;
                                        if (document.getElementById("link") != null){
                                            
                                            document.getElementById("link").click();
                                        }

                                        else{
                                            alert(data);
                                        }
                                            
                                        
                                        closeForm();
                                    },

                                    // failure: function(data) {
                                    //     alert("Wrong Key Entered!! Please try again..");
                                    // }


                                });
                            }

                            function getKey(){
                                m3 = uid;
                                m4 = document.getElementById("encKey").value;
                                m5 = document.getElementById("pvtPin").value;

                                $.ajax({
                                    type: "GET",
                                    url: "test1.php",
                                    data: {
                                        fileID: m3,
                                        encKey: m4,
                                        pvtPin: m5
                                    },
                                    success: function(data) {
                                        alert(data);
                                        
                                    }


                                });

                            }
                        </script>

                    </div><!-- /End row -->
                </section>
            </div>
        </div>
    </div>
</body>

</html>