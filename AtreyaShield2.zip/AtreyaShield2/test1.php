<?php

//PRIVATE KEY
//mihir: 789789
//sarjan: 768768
//aditya: 123456
//anish: 234567

include('session_manager.php');

$user_id = $_SESSION['id'];
// Database configuration
$dbHost     = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName     = "atreyashield";

// Create database connection
$db = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

$fileID = $_GET['fileID'];
$encKey = $_GET['encKey'];
$pvtPin = $_GET['pvtPin'];


//FETCHING THE SENDER NAME, EMAIL ID 
$sql = $db->prepare("SELECT * FROM users WHERE id='$user_id'");
$sql->execute();
$result = $sql->get_result();
$r = $result->fetch_array(MYSQLI_ASSOC);
$userPublicKey = $r['PublicKey'];
$userPrivateKey = $r['PrivateKey'];

// echo "userPublicKey: ".$userPublicKey."<br>";
// echo "userPrivateKey: ".$userPrivateKey."<br>";

@$decryptPrivateKey = openssl_decrypt($userPrivateKey, 'aes-256-cbc',""); 
//echo "decryptPrivateKey: ".$decryptPrivateKey."<br>";

//FETCHING THE FILE NAME 
$sql2 = $db->prepare("SELECT * FROM files WHERE id='$fileID'");
$sql2->execute();
$result2 = $sql2->get_result();
$r2 = $result2->fetch_array(MYSQLI_ASSOC);
$filePrivateKey = $r2['privateKey'];
//echo "filePrivate: ".$filePrivateKey."<br>";

@$encryptedPrivateKey = openssl_encrypt($filePrivateKey, 'aes-256-cbc',$userPublicKey); 
//echo "decryptedPrivateKey: ".$decryptPrivateKey."<br>";

if ($encKey == $encryptedPrivateKey){
    if ($pvtPin == $decryptPrivateKey){
        echo "File Private Key: ".$filePrivateKey;
    }
    else{
        echo "Incorrect Private Pin. Please try again!";
    }
}
else{
    echo "Wrong Encrypted Key. Please try again!";
}
//A003ohAaUgvUN+vGp9SN9Q==



?>