<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

require 'vendor/autoload.php';
$from = "mikidevghare123@gmail.com";
$to = "mikidevghare123@gmail.com";
$subject = "hello!!";
$cc = "";
$body = "hello!!";
function sendmail($from, $to, $cc, $subject, $body, $debug = false)
{
    $mail = new PHPMailer(true);
    $mail->SMTPDebug = SMTP::DEBUG_SERVER; //Enable verbose debug output
    $mail->isSMTP(); //Send using SMTP
    $mail->SMTPDebug = 0;
    $mail->Host = 'smtp.gmail.com'; //Set the SMTP server to send through
    $mail->SMTPAuth = true; //Enable SMTP authentication
    $mail->Username = 'mikidevghare123@gmail.com'; //SMTP username
    $mail->Password = 'nzrwdbcdskorngzh'; //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; //Enable implicit TLS encryption
    $mail->Port = 465; //TCP port to connect to; use 587 if you have set SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS
    $mail->SetFrom($from);
    $mail->AddAddress($to);
    $mail->Subject = $subject;
    $mail->IsHTML(true);
    $mail->Body = $body;
    if ($cc != "") {
        $mail->AddCC($cc);
    }
    if (!$mail->Send() && $debug) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        return 1;
    }
}
sendmail($from, $to, $cc, $subject, $body);
if (sendmail($from, $to, $cc, $subject, $body) == 1) {
    echo "email send";
} else {
    echo "email failed";
}