<!-- gxbucyzoiuolntgn email: atreyashield@gmail.com Password: @!M!hAn!$ar589 -->
<?php

include('session_manager.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

require 'vendor/autoload.php';

$user_id = $_SESSION['id'];
// Database configuration
$dbHost     = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName     = "atreyashield";


// Create database connection
$db = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

//FETCHING THE SENDER NAME, EMAIL ID 
$sql = $db->prepare("SELECT * FROM users WHERE id='$user_id'");
$sql->execute();
$result = $sql->get_result();
$r = $result->fetch_array(MYSQLI_ASSOC);
$senderName = $r['username'];
$senderEmail = $r['recovery_email'];

$fileID = $_GET['fileID'];
$receiverEmail = $_GET['receiver'];

//FETCHING THE RECEIVER'S ID
$sql1 = $db->prepare("SELECT * FROM users WHERE recovery_email='$receiverEmail'");
$sql1->execute();
$result1 = $sql1->get_result();
$r1 = $result1->fetch_array(MYSQLI_ASSOC);
$receiverID = $r1['id'];
$pubKey = $r1['PublicKey'];

//FETCHING THE FILE NAME 
$sql2 = $db->prepare("SELECT * FROM files WHERE id='$fileID'");
$sql2->execute();
$result2 = $sql2->get_result();
$r2 = $result2->fetch_array(MYSQLI_ASSOC);
$fileName = $r2['image'];
$pvtKey = $r2['privateKey'];

@$encryptedKey = openssl_encrypt($pvtKey, 'aes-256-cbc',$pubKey); 
// echo $fileName;

$from = "atreyashield@gmail.com";
$to = $receiverEmail;
$subject = "A file has been shared with you.";
$cc = "";
$body = '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "https://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <style type="text/css" nonce="Frhlhu99BzM2ri0PtkHvMA">
      body,
      td,
      div,
      p,
      a,
      input {
        font-family: arial, sans-serif;
      }
    </style>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="shortcut icon" href="" type="image/x-icon" />
    <title>Mail Template</title>
    <style type="text/css" nonce="Frhlhu99BzM2ri0PtkHvMA">
      body,
      td {
        font-size: 13px;
      }

      a:link,
      a:active {
        color: #1155cc;
        text-decoration: none;
      }

      a:hover {
        text-decoration: underline;
        cursor: pointer;
      }

      a:visited {
        color: #6611cc;
      }

      img {
        border: 0px;
      }

      pre {
        white-space: pre;
        white-space: -moz-pre-wrap;
        white-space: -o-pre-wrap;
        white-space: pre-wrap;
        word-wrap: break-word;
        max-width: 800px;
        overflow: auto;
      }

      .logo {
        left: -7px;
        position: relative;
      }
    </style>

    <body>
      <div class="bodycontainer">
        <div class="maincontent">
          <table
            width="100%"
            cellpadding="0"
            cellspacing="0"
            border="0"
            class="message"
          >
            <tr>
              <td align="right">
                <tr>
                  <td colspan="2" style="padding-bottom: 4px">
                    <tr>
                      <td colspan="2">
                        <table
                          width="100%"
                          cellpadding="12"
                          cellspacing="0"
                          border="0"
                        >
                          <tr>
                            <td>
                              <div style="overflow: hidden">
                                <font size="-1">
                                  <div>
                                    <table
                                      style="
                                        border-collapse: collapse;
                                        width: 100%;
                                        background-color: #370f63;
                                        text-align: center;
                                      "
                                      role="presentation"
                                    >
                                      <tr>
                                        <td style="padding: 24px 0 16px 0">
                                          <table
                                            style="
                                              border-collapse: collapse;
                                              font-family: Roboto, Arial,
                                                Helvetica, sans-serif;
                                              word-wrap: break-word;
                                              word-break: break-word;
                                              display: inline-block;
                                              width: 90%;
                                              max-width: 700px;
                                              min-width: 280px;
                                              text-align: left;
                                            "
                                            role="presentation"
                                          >
                                            <tr>
                                              <td style="padding: 0">
                                                <table
                                                  style="
                                                    width: 100%;
                                                    border: 1px solid #dadce0;
                                                    border-radius: 8px;
                                                    border-spacing: 0;
                                                    table-layout: fixed;
                                                    border-collapse: separate;
                                                  "
                                                  role="presentation"
                                                >
                                                  <tr>
                                                    <td
                                                      style="padding: 4.5%"
                                                      dir="ltr"
                                                    >
                                                      <div
                                                        style="
                                                          margin-bottom: 32px;
                                                          font-family: Google
                                                              Sans,
                                                            Roboto, Arial,
                                                            Helvetica,
                                                            sans-serif;
                                                          font-style: normal;
                                                          font-size: 28px;
                                                          line-height: 36px;
                                                          color: #dadce0;
                                                        "
                                                      >
                                                        #name
                                                      </div>
                                                      <table
                                                        style="
                                                          border-collapse: collapse;
                                                          font-family: Roboto,
                                                            Arial, Helvetica,
                                                            sans-serif;
                                                          font-size: 16px;
                                                          line-height: 24px;
                                                          color: #dadce0;
                                                          letter-spacing: 0.1px;
                                                          table-layout: fixed;
                                                          width: 100%;
                                                        "
                                                        role="presentation"
                                                      >
                                                        <tr>
                                                          <td
                                                            style="
                                                              padding: 0;
                                                              vertical-align: top;
                                                              width: 50px;
                                                            "
                                                          >
                                                            <div>
                                                              <img
                                                                style="
                                                                  border-radius: 50%;
                                                                  display: block;
                                                                "
                                                                width="50"
                                                                height="50"
                                                                src="https://ci5.googleusercontent.com/proxy/UdBKn_RzxvI0tpFeaHZH6qjRQflXD1FVkaKHQLxpPMCyp4rb_JsvRhUd3X6hT680rGauqrNvGg4v5Lh0GZuxPsl8_pNVA1bhQMf9F71p=s0-d-e1-ft#https://ssl.gstatic.com/s2/profiles/images/silhouette64.png"
                                                                alt="Unknown profile photo"
                                                              />
                                                            </div>
                                                          </td>
                                                          <td
                                                            style="
                                                              padding: 0;
                                                              vertical-align: top;
                                                              padding-left: 12px;
                                                            "
                                                          >
                                                            <div
                                                              style="
                                                                padding-top: 12px;
                                                              "
                                                            >
                                                              #name (<a
                                                                href="mailto:#@gnu.ac.in"
                                                                style="
                                                                  color: inherit;
                                                                  text-decoration: none;
                                                                "
                                                                target="_blank"
                                                                >#@gnu.ac.in</a
                                                              >) has invited you
                                                              to <b>edit</b> the
                                                              following
                                                              document:
                                                            </div>
                                                          </td>
                                                        </tr>
                                                      </table>
                                                      <table
                                                        style="
                                                          border-spacing: 0 4px;
                                                          table-layout: fixed;
                                                          width: 100%;
                                                        "
                                                        role="presentation"
                                                      >
                                                        <tr
                                                          style="height: 28px"
                                                        ></tr>
                                                        <tr>
                                                          <td
                                                            style="padding: 0"
                                                          >
                                                          
                                                            <a
                                                              href=""
                                                              style="
                                                                color: #dadce0;
                                                                display: inline-block;
                                                                max-width: 100%;
                                                                text-decoration: none;
                                                                vertical-align: top;
                                                                border: 1px
                                                                  solid #dadce0;
                                                                border-radius: 16px;
                                                                white-space: nowrap;
                                                              "
                                                              target="_blank"
                                                              data-saferedirecturl=""
                                                            >
                                                              <div
                                                                style="
                                                                  line-height: 18px;
                                                                  overflow: hidden;
                                                                  text-overflow: ellipsis;
                                                                  padding: 6px
                                                                    12px;
                                                                "
                                                              >
                                                              
                                                                <span
                                                                  style="
                                                                    font: 500
                                                                        14px/18px
                                                                        Google
                                                                        Sans,
                                                                      Roboto,
                                                                      Arial,
                                                                      Helvetica,
                                                                      sans-serif;
                                                                    display: inline;
                                                                    letter-spacing: 0.2px;
                                                                  "
                                                                  >Key: #encryptedKey</span
                                                                >
                                                              </div>
                                                            </a>
                                                          </td>
                                                        </tr>

                                                        <tr>
                                                          <td
                                                            style="padding: 0"
                                                          >
                                                            <a
                                                              href=""
                                                              style="
                                                                color: #dadce0;
                                                                display: inline-block;
                                                                max-width: 100%;
                                                                text-decoration: none;
                                                                vertical-align: top;
                                                                border: 1px
                                                                  solid #dadce0;
                                                                border-radius: 16px;
                                                                white-space: nowrap;
                                                              "
                                                              target="_blank"
                                                              data-saferedirecturl=""
                                                            >
                                                              <div
                                                                style="
                                                                  line-height: 18px;
                                                                  overflow: hidden;
                                                                  text-overflow: ellipsis;
                                                                  padding: 6px
                                                                    12px;
                                                                "
                                                              >
                                                                <span
                                                                  style="
                                                                    font: 500
                                                                        14px/18px
                                                                        Google
                                                                        Sans,
                                                                      Roboto,
                                                                      Arial,
                                                                      Helvetica,
                                                                      sans-serif;
                                                                    display: inline;
                                                                    letter-spacing: 0.2px;
                                                                  "
                                                                  >#filename</span
                                                                >
                                                              </div>
                                                            </a>
                                                          </td>
                                                        </tr>
                                                      </table>
                                                      <table
                                                        style="
                                                          border-collapse: collapse;
                                                        "
                                                        role="presentation"
                                                      >
                                                        <tr
                                                          style="height: 32px"
                                                        >
                                                          <td></td>
                                                        </tr>
                                                      </table>
                                                      <div>
                                                        <a
                                                          href="#link"
                                                          role="button"
                                                          style="
                                                            padding: 0 24px;
                                                            font: 500 14px/36px
                                                                Google Sans,
                                                              Roboto, Arial,
                                                              Helvetica,
                                                              sans-serif;
                                                            border: none;
                                                            border-radius: 18px;
                                                            box-sizing: border-box;
                                                            display: inline-block;
                                                            letter-spacing: 0.25px;
                                                            min-height: 36px;
                                                            text-align: center;
                                                            text-decoration: none;
                                                            background-color: #dadce0;
                                                            color: #6611cc;
                                                          "
                                                          target="_blank"
                                                          data-saferedirecturl="#link"
                                                          >Open</a
                                                        >
                                                      </div>
                                                    </td>
                                                  </tr>
                                                </table>
                                              </td>
                                            </tr>
                                          </table>
                                        </td>
                                      </tr>
                                    </table>
                                  </div>
                                </font>
                              </div>
                            </td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                  </td>
                </tr>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </body>
  </head>
</html>
';

$pattern1 = '/#name/i';
$body = preg_replace($pattern1, $senderName, $body);

$pattern2 = '/#@gnu.ac.in/i';
$body = preg_replace($pattern2, $senderEmail, $body);

$pattern3 = '/#filename/i';
$body = preg_replace($pattern3, $fileName, $body);

$pattern4 = '/#encryptedKey/i';
$body = preg_replace($pattern4, $encryptedKey, $body);

$pattern5 = '/#link/i';
$body = preg_replace($pattern5, "localhost/AtreyaShield2/signup.php", $body);


function sendmail($from, $to, $cc, $subject, $body, $debug = false)
{
  $mail = new PHPMailer(true);
  $mail->SMTPDebug = SMTP::DEBUG_SERVER; //Enable verbose debug output
  $mail->isSMTP(); //Send using SMTP
  $mail->SMTPDebug = 0;
  $mail->Host = 'smtp.gmail.com'; //Set the SMTP server to send through
  $mail->SMTPAuth = true; //Enable SMTP authentication
  $mail->Username = 'atreyashield@gmail.com'; //SMTP username
  $mail->Password = 'gxbucyzoiuolntgn'; //SMTP password
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; //Enable implicit TLS encryption
  $mail->Port = 465; //TCP port to connect to; use 587 if you have set SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS
  $mail->SetFrom($from);
  $mail->AddAddress($to);
  $mail->Subject = $subject;
  $mail->IsHTML(true);
  $mail->Body = $body;

  if ($cc != "") {
    $mail->AddCC($cc);
  }
  if (!$mail->Send() && $debug) {
    echo "Mailer Error: " . $mail->ErrorInfo;
  } else {
    return 1;
  }
}
// $dem =  sendmail($from, $to, $cc, $subject, $body);
// echo '<script type="text/javascript">';
// echo 'alert("'.$dem.'")</script>';
// echo '</script>';


if (sendmail($from, $to, $cc, $subject, $body) == 1) {
  date_default_timezone_set("Asia/Kolkata");
  $time = date('h:i:sa');
  $date = date('y-m-d');
  $sql3 = "INSERT into received (`FileName`, `SharedTime`,`SharedDate`,`SharedBy`,`RecID`,`FileID`) VALUES ('$fileName','$time','$date','$senderName','$receiverID','$fileID')";
  mysqli_query($db, $sql3);
} else {
  echo "email failed";
}
