<?php include('session_manager.php');
$user_id = $_SESSION['id'];

// Database configuration
$dbHost     = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName     = "atreyashield";

// Create database connection
$db = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

$fileID= $_GET[ "fileID"];

#sql query to upload
$sql = "DELETE FROM files WHERE `id`='$fileID'";


if (mysqli_query($db, $sql)) {
    echo '<script type="text/javascript">';
    echo 'alert("File Deleted Successfully!")';
    echo '</script>';
} 
else {
    echo '<script type="text/javascript">';
    echo 'alert("File not uploaded. Please try again!")';
    echo '</script>';
}
