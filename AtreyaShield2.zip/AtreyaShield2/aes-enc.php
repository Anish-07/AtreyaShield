<?php

function encryptFile($inputFile, $outputFile, $key) {
    // Generate a random initialization vector
    $iv = openssl_random_pseudo_bytes(16);
    // echo $iv;

    // Open the input and output files
    $inFile = fopen($inputFile, "rb");
    $outFile = fopen($outputFile, "wb");

    // Write the initialization vector to the output file
    fwrite($outFile, $iv);

    // Encrypt the file data with AES-256
    $cipherText = openssl_encrypt(stream_get_contents($inFile), "aes-256-cbc", $key, OPENSSL_RAW_DATA, $iv);

    // Write the encrypted data to the output file
    fwrite($outFile, $cipherText);

    // Close the input and output files
    fclose($inFile);
    fclose($outFile);
}
//encryptFile('E:/SEM 6/NS/Practical7/samplee.txt', 'E:/Xampp/htdocs/AtreyaShield2/serverupload/encrypted_prac1.txt', 1);
// echo $fpDest;
// echo "File encrypted!\n";
// echo 'Memory usage: ' . round(memory_get_usage() / 1048576, 2) . "M\n";